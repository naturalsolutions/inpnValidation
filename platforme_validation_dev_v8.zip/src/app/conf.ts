export const Conf = {
    apiBaseUrl: 'https://inpn2.mnhn.fr/inpn-web-services/inpnespece/',
    casBaseUrl: 'https://test-cas-patrinat.mnhn.fr/auth/oauth2.0/',//'https://cas-patrinat.mnhn.fr/auth/oauth2.0/', 
    apiBaseUrl2:'https://inpn.mnhn.fr/inpn-web-services/',
    taxrefUrl: 'https://taxref.mnhn.fr/api1/taxa/search?'
};
