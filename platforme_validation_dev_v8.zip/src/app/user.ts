export interface User {
    attributes: {
        AVATAR_PATH?: string,
        CIVILITE?: string,
        EMAIL?: string,
        GROUPS?: string,
        ID_UTILISATEUR?: number,
        LOGIN?: string,
        NOM?: string,
        PRENOM?: string,
    }
    id?: string,

}